import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'link';
  size?: 'sm' | 'md' | 'lg';
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  size = 'md', 
  className = '', 
  ...props 
}) => {
  
  const baseStyles = "inline-flex items-center justify-center rounded-full font-medium transition-all duration-300 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    primary: "bg-black text-white dark:bg-white dark:text-black hover:bg-zinc-800 dark:hover:bg-gray-200 active:scale-95 shadow-lg dark:shadow-[0_0_20px_rgba(255,255,255,0.3)]",
    secondary: "bg-zinc-200 text-zinc-900 dark:bg-zinc-800 dark:text-white hover:bg-zinc-300 dark:hover:bg-zinc-700 active:scale-95 border border-zinc-300 dark:border-zinc-700",
    outline: "bg-transparent border border-zinc-300 dark:border-white/30 text-zinc-900 dark:text-white hover:bg-zinc-100 dark:hover:bg-white/10 active:scale-95",
    link: "text-blue-500 hover:text-blue-600 dark:text-blue-400 dark:hover:text-blue-300 hover:underline p-0 h-auto"
  };
  
  const sizes = {
    sm: "text-xs px-4 py-2",
    md: "text-sm px-6 py-3",
    lg: "text-lg px-8 py-4"
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};